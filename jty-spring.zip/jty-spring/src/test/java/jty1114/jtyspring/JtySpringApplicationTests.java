package jty1114.jtyspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JtySpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
