package jty1114.jtyspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JtySpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JtySpringApplication.class, args);
	}

}
